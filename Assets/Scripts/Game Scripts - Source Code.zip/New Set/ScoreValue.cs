using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreValue : MonoBehaviour
{
    public int scoreAdd;
    public int scoreDeduct;
    public int healthAdd;
    public int healthDeduct;
}
